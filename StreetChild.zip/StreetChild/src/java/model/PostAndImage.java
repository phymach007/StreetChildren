/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Blob;

/**
 *
 * @author Lenovo
 */
public class PostAndImage {
    private String post;
    private String filename1;

    public String getFilename1() {
        return filename1;
    }

    public void setFilename1(String filename1) {
        this.filename1 = filename1;
    }

    public String getFilename2() {
        return filename2;
    }

    public void setFilename2(String filename2) {
        this.filename2 = filename2;
    }

    public String getFilename3() {
        return filename3;
    }

    public void setFilename3(String filename3) {
        this.filename3 = filename3;
    }

    public String getFilename4() {
        return filename4;
    }

    public void setFilename4(String filename4) {
        this.filename4 = filename4;
    }

    public String getFilename5() {
        return filename5;
    }

    public void setFilename5(String filename5) {
        this.filename5 = filename5;
    }
     private String filename2;
      private String filename3;
       private String filename4;
        private String filename5;

   

   
    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }
    
}
