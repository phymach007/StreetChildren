/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Lenovo
 */
public class MailSend {
    
    private String mailsend;

    public String getMailsend() {
        return mailsend;
    }

    public void setMailsend(String mailsend) {
        this.mailsend = mailsend;
    }

   
    
    
}
