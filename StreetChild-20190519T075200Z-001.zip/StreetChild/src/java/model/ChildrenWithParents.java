/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Lenovo
 */
public class ChildrenWithParents {
    private String ChildName;

    public String getChildName() {
        return ChildName;
    }

    public void setChildName(String ChildName) {
        this.ChildName = ChildName;
    }

    public String getAge() {
        return Age;
    }

    public void setAge(String Age) {
        this.Age = Age;
    }

    public String getParentName() {
        return ParentName;
    }

    public void setParentName(String ParentName) {
        this.ParentName = ParentName;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getContactNO() {
        return ContactNO;
    }

    public void setContactNO(String ContactNO) {
        this.ContactNO = ContactNO;
    }

    public String getOccupation() {
        return Occupation;
    }

    public void setOccupation(String Occupation) {
        this.Occupation = Occupation;
    }

    public String getInstitution() {
        return Institution;
    }

    public void setInstitution(String Institution) {
        this.Institution = Institution;
    }
    private String Age;
    private String ParentName;
    private String Address;
    private String ContactNO;
    private String Occupation;
    private String Institution;
    
}
